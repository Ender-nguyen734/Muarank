<?php

/**
 *     _    __                  _                                     _
 *    | |  / /                 | |                                   | |
 *    | | / /                  | |                                   | |
 *    | |/ / _   _  ____   ____| | ______ ____   _____ ______   ____ | | __
 *    | |\ \| | | |/ __ \ / __ \ |/ /  __/ __ \ / __  | _  _ \ / __ \| |/ /
 *    | | \ \ \_| | <__> |  ___/   <| / | <__> | <__| | |\ |\ | <__> |   <
 * By |_|  \_\__  |\___  |\____|_|\_\_|  \____^_\___  |_||_||_|\____^_\|\_\
 *              | |    | |                          | |
 *           ___/ | ___/ |                          | |
 *          |____/ |____/                           |_|
 *
 * A PocketMine-MP plugin that shows information about ranks in the server
 * Copyright (C) 2020-2021 Kygekraqmak, KygekTeam
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 */

declare(strict_types=1);

namespace Kygekraqmak\KygekRanksUI;

use pocketmine\command\Command;
use pocketmine\player\Player;
use pocketmine\command\CommandSender;
use pocketmine\plugin\PluginOwned;
use pocketmine\utils\TextFormat;

class Commands extends Command implements PluginOwned {

    private Main $main;
    private string $prefix;

    public function __construct(Main $main, string $desc, array $aliases) {
        $this->main = $main;
        $this->prefix = TextFormat::YELLOW . "§c§a§l[MuaRank] ";
        if ($desc == null) {
            $desc = "§cMua các loại rank của máy chủ";
        }
        parent::__construct("ranks", $desc, "/ranks", $aliases);
        $this->setPermission("kygekranksui.ranks");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) : bool {
        if (!$sender instanceof Player) $sender->sendMessage($this->prefix . TextFormat::RED . "Thực hiện lệnh ở game!");
        else {
            if ($this->testPermissionSilent($sender)) {
                if (file_exists($this->getOwningPlugin()->getDataFolder()."config.yml")) {
                    $this->getOwningPlugin()->getConfig()->reload();
                    $this->getOwningPlugin()->ranksMenu($sender);
                } else {
                    $sender->sendMessage($this->prefix . TextFormat::RED . "Không tìm thấy config của plugin,hãy khởi động server!");
                }
            } else {
                $sender->sendMessage($this->prefix . TextFormat::RED . "Bạn không có đủ quyền để thực hiênh hành động này!");
            }
        }
        return true;
    }

    public function getOwningPlugin() : Main {
        return $this->main;
    }

}
